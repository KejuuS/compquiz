module.exports = {
  content: [
    "./src/**/*.{js,jsx}",
    "./src/index.jsx",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
